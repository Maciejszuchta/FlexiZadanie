<script setup>
import { ref } from 'vue'

const numberOfUsers = ref(0);
let users = ref([]);

async function fetchData() {
  try {
    const request = await fetch(`https://localhost:7136/People?N=${numberOfUsers.value}`);
    const result = await request.json();
    users.value = result.results;
  }
  catch (error) {
    users.value = [];
    alert("Failed to get user data.");
  }
}

function getContentImageLink(url) {
  return url;
}

</script>
<template>
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col col-md-4">
        <div class="input-group mb-3">
          <h1 class="user-fetch">Fetch Users</h1>
          <input id="numberOfUsers" type="number" class="form-control" placeholder="0" aria-label="Number of users"
            aria-describedby="getUsersBtn" v-model="numberOfUsers" min="0">
          <button class="btn btn-primary" @click="fetchData()" type="button" id="getUsersBtn">Fetch</button>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div v-for="user in users" class="col-md-4">
        <div class="card mb-3" style="border-radius: .5rem;">
          <div class="row g-0">
            <div class="col-md-4 gradient-custom text-center"
              style="border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;">
              <img :src="getContentImageLink(user.picture.medium)" alt="Avatar" class="img-fluid my-5"
                style="width: 80px;" />
              <h5>{{ user.name.title }}</h5>
              <h5>{{ user.name.first }}</h5>
              <h5>{{ user.name.last }}</h5>
              <h6>Age:</h6>
              <p>{{ user.registered.age }}</p>
            </div>
            <div class="col-md-8">
              <div class="card-body p-4">
                <h6>Information</h6>
                <hr class="mt-0 mb-4">
                <div class="row pt-1">
                  <div class="col-6 mb-3">
                    <h6>Email</h6>
                    <p class="text-muted">{{ user.email }}</p>
                  </div>
                  <div class="col-6 mb-3">
                    <h6>Phone</h6>
                    <p class="text-muted">{{ user.phone }}</p>
                  </div>
                </div>
                <h6>Location</h6>
                <hr class="mt-0 mb-4">
                <div class="row pt-1">
                  <div class="col-6 mb-3">
                    <h6>City</h6>
                    <p class="text-muted">{{ user.location.city }}</p>
                  </div>
                  <div class="col-6 mb-3">
                    <h6>State</h6>
                    <p class="text-muted">{{ user.location.state }}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.gradient-custom {
  /* fallback for old browsers */
  background: #f6d365;

  /* Chrome 10-25, Safari 5.1-6 */
  background: -webkit-linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1));

  /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  background: linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1))
}


ul {
  list-style-type: none;
  /* Remove bullets */
  padding: 0;
  /* Remove padding */
  margin: 0;
  /* Remove margins */
}

h1.user-fetch{
  margin-right: 1em;
}
div.row.justify-content-md-center{
  margin-top: 1em;
}
</style>

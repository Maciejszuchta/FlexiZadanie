﻿using FlexiApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace FlexiApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PeopleController : Controller
    {

        private readonly IUserService _userService;
        private readonly ILogger<PeopleController> _logger;


        public PeopleController(IUserService userService, ILogger<PeopleController> logger)
        {
            _userService = userService;
            _logger = logger;   
        }

        [HttpGet]
        public async Task<IActionResult> GetUsers(int N)
        {
            try
            {
                var users = await _userService.GetUsers(N);
                if(users == null)
                {
                    return BadRequest("Failed to get users");
                }
                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest("Failed to get users");
            }
        }
    }
}

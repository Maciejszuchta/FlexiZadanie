﻿namespace FlexiApi.DataModels
{
    public class AppSettings
    {
        public string UsersHttpEndpoint { get; set; }
    }
}

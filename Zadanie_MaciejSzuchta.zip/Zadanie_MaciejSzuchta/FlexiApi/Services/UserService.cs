﻿using FlexiApi.DataModels;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;

namespace FlexiApi.Services
{
    public class UserService : IUserService
    {
        private readonly IOptions<AppSettings> _options;
        public UserService(IOptions<AppSettings> options)
        {
            _options = options;
        }
        public async Task<string?> GetUsers(int numbetOfUsers)
        {
            var endpoint = _options.Value.UsersHttpEndpoint;
            using(var httpClient =  new HttpClient())
            {
                HttpResponseMessage response = await httpClient.GetAsync($"{endpoint}/?results={numbetOfUsers}");
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                } 
                return await response.Content.ReadAsStringAsync();
            }
        }
    }
}

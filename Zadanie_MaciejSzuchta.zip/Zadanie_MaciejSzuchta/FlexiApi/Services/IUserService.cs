﻿using Newtonsoft.Json.Linq;

namespace FlexiApi.Services
{
    public interface IUserService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="numbetOfUsers"></param>
        /// <returns><see cref="null"/> If failed to get users</returns>
        public Task<string?> GetUsers(int numbetOfUsers);
    }
}
